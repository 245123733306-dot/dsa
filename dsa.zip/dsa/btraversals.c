#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *left,*right;
};
struct node *root=NULL;

void inorder(struct node* root)
{
	if(root)
	{
		inorder(root->left);
		printf("%d\t",root->data);
		inorder(root->right);
	}
	else 
		return;
}
void preorder(struct node* root)
{
	if(root)
	{
		printf("%d\t",root->data);
		preorder(root->left);
		preorder(root->right);
	}
	else
		return;
}
void postorder(struct node* root)
{
	if(root)
	{
		postorder(root->left);
		postorder(root->right);
		printf("%d\t",root->data);
	}
	else
		return;
}
struct node *create()
{
	struct node *nn;
	int data,ch;
	nn=(struct node*)malloc(sizeof(struct node));
	printf("\nPress 1 for new node and 0 to NULL node\n");
	printf("enter your choice:");
	scanf("%d",&ch);
	if(ch==0)
	{
		return NULL;
	}
	else
	{
		printf("enter the data");
		scanf("%d",&data);
		nn->data=data;
		printf("enter the left child of %d",data);
		nn->left=create();
		printf("enter the right child of %d",data);
		nn->right=create();
		return nn;
	}
}
int main()
{
	int ch;
	do
	{
		printf("\n Binary Tree Traversals\n1.create\n2.Inorder\n3.preorder\n4.postorder\n5.Exit\n");
		printf("enter your choice");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				root=create();
				break;
			case 2:
				if(root==NULL)
					printf("tree id empty\n");
				else
					inorder(root);
				break;
			case 3:
				if(root==NULL)
					printf("tree id empty\n");
                                else
                                        preorder(root);
                                break;
			case 4:
                                if(root==NULL)
                                        printf("tree id empty\n");
                                else
                                        postorder(root);
                                break;
                        default:printf("wrong Choice");
		}
	}while(ch>=1&&ch<=4);

}
