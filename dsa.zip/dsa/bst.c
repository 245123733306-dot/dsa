#include<stdio.h>
#include<stdlib.h>
typedef struct bst
{
	int data;
	struct bst *left,*right;
}node;
node *root,*curr,*parent;
void insert(int);
void inorder(node *);
void search(int);
void del(int);
int main()
{
	int ch,ele;
	root=NULL;
	printf("\nProgram for binary search tree");
	printf("\n=====================\n");
	while(1)
	{
		printf("\n1.create or add\n2.Search\n3.Delete\n4.Display\n5.Exit\n");
		printf("\n\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1: printf("\nEnter the element:");
				scanf("%d",&ele);
				insert(ele);
				break;
			case 2:printf("\nenter the elementwhich you want to search:");
			       scanf("%d",&ele);
			       search(ele);
			       break;
			case 3 : printf("\nenter the element u wish to delete");
				 scanf("%d",&ele);
				 del(ele);
				 break;
			case 4:if(root==NULL)
				       printf("\ntree is empty\n");
			       else
			       {
				       printf("\nThe tree is :");
				       inorder(root);
			       }
			       break;
			default:printf("\nExiting from the program\n");
			       exit(0);
		}
	}
}	
void insert(int ele)
{
	node *nn;
	curr=root;
	while(curr!=NULL)
	{
		parent=curr;
		if(ele<curr->data)
		{
			curr=curr->left;
		}
		else if(ele>curr->data)
		{
			curr=curr->right;
		}
		else{
			printf("\n duplicate keys are not allowed\n");
			return;
		}
	}
	nn=(node*)malloc(sizeof(node));
	nn->data=ele;
	nn->left=nn->right=NULL;
	if(root!=NULL)
	{
		if(ele<parent->data)
			parent->left=nn;
		else
			parent->right=nn;
	}
	else
		root=nn;
}
void search(int ele)
{
	int f=0;
	curr=root;
	while(curr!=NULL)
	{
		if(curr->data==ele)
		{
			printf("\nThe element is present");
		       f=1;
	       break;
		}
 parent=curr;
if(curr->data>ele)
	curr=curr->left;
else
	curr=curr->right;
	}
if(f==0)
	printf("\nElement is not present in tree\n");
}
void del(int ele)
{
	node *in_succ=NULL;
	if(root==NULL)
	{
		printf("\ntree is empty\n");
		return;
	}
	curr=root;parent=NULL;
	while(curr!=NULL)
	{
		if(curr->data==ele)
		{
			break;
		}
		else
		{
			parent=curr;
			if(ele>curr->data)
				curr=curr->right;
			else
				curr=curr->left;
		}
	}
	if(curr!=NULL)
	{
		if(curr->left!=NULL&&curr->right!=NULL)
		{
			in_succ=curr->right;
			if(in_succ->left==NULL&&in_succ->right==NULL)
			{
				curr->data=in_succ->data;
				curr->right=NULL;
				free(in_succ);
			}
			else{
				if(in_succ->right!=NULL&&in_succ->left==NULL)
				{
					curr->data=in_succ->data;
					curr->right=in_succ->right;
					free(in_succ);
				}
				else{
					while(in_succ->left!=NULL)
					{
						parent=in_succ;
						in_succ=in_succ->left;
					}
					curr->data=in_succ->data;
					if(in_succ->right!=NULL)
						parent->left=in_succ->right;
					else
						parent->left=NULL;
					free(in_succ);
				}
				printf("\n NOde is delteed");
				return;
			}
		}
		if(curr->left!=NULL&&curr->right==NULL)
		{
			
if(parent!=NULL){

if(parent->left==curr)

parent->left=curr->left;

else

parent->right-curr->left;

}

else //if deleting node is root

root=curr->left;

printf("\nNode is deleted !!");

free(curr);

return;

}

if(curr->left==NULL && curr->right!=NULL)

{ 
	if(parent!=NULL) {

if(parent->left==curr)

parent->left=curr->right;

else

parent->right-curr->right;

}

else //if deleting node is root

root=curr->right;
printf("\nNode is deleted!");

free(curr);

return;
}
if(curr->left==NULL && curr->right==NULL)

{

if(parent!=NULL)
{
if(parent->left==curr)

parent->left=NULL;

else

parent->right=NULL;
}
else //if deleting node is root

root=NULL;

printf("\nNode is deleted!");

free(curr);

return;
}
}
else

printf("\n Element is not present in tree\n");

}
void inorder(node *root)

{
       	if(root!=NULL)

{

inorder(root->left);
printf("%d",root->data);

inorder(root->right);

}
}
