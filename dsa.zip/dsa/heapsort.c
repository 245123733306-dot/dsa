#include<stdio.h>
#include<stdlib.h>
void heapsort(int a[],int n);
void heapify(int *a,int i,int n);
int main()
{
	int *a,i,n;
	printf("enter size of list:");
	scanf("%d",&n);
	a=(int*)malloc((n+1)*sizeof(int));
	printf("\nEnter %d elements:",n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\nElements before sorting are:\n");
        for(int i=1;i<=n;i++)
		printf("%d\t",a[i]);
	heapsort(a,n);
	printf("\nElements after sorting are:\n");
	for(int i=1;i<=n;i++)
                printf("%d\t",a[i]);
        return 0;
}
void heapsort(int *a,int n)
{
	int x;
	for(int i=n/2;i>=1;i--)
		heapify(a,i,n);
	for(int i=n;i>=2;i--)
	{
		x=a[i];
		a[i]=a[1];
		a[1]=x;
		heapify(a,1,i-1);
	}
}
void heapify(int *a,int i,int n)
{
	int j,x;
	j=2*i;
	while(j<=n)
	{
		if(j<n)
		{
			if(a[j]<a[j+1])
				j++;
		}
		if(a[i],a[j])
		{
			x=a[i];
			a[i]=a[j];
			a[j]=x;
		}
		i=j;
		j=2*i;
	}
}


