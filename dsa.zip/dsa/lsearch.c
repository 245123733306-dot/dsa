
#include<stdio.h>
#include<stdlib.h>
int main()
{
        int *a,i,n,key;
        printf("enter the size of list:");
        scanf("%d",&n);
        a=(int*)malloc((n+1)*sizeof(int));
        printf("\nEnter %d elements:",n);
        for(i=0;i<n;i++)
        {
                scanf("%d",&a[i]);
        }
        printf("\n Elements in the list are:\n");
        for(i=0;i<n;i++)
                printf("%d\t",a[i]);
        printf("\nEnter an element to search:\n");
        scanf("%d",&key);
        for(i=0;i<n;i++)
	{
		if(key==a[i]){
			printf("\nElement found at %d position\n",i+1);
			break;
		}
	}
	if(i==n)
		printf("\n Element not found in the List\n");
	return 0;
}
