#include<stdio.h>
#include<stdlib.h>
#define SIZE 10
int h[SIZE]={NULL};
void insert()
{
	int ele,index,i,flag=0,hkey;
	printf("\nenter a value to insertinto hash table\n");
	scanf("%d",&ele);
	hkey=ele%SIZE;
	 for(i=0;i<SIZE;i++)
        {       
                index=(hkey+i)%SIZE;
                if(h[index]==NULL)
                {       
                        h[index]=ele;
                        break;
                }       
        }       
        if(i==SIZE)
                printf("\nElement cannot be inserted as Hash Table is FULL\n");
}       
void search()
{
	int ele,index,i,flag=0,hkey;
	printf("\nenter search elmnet\n");
	scanf("%d",&ele);
	hkey=ele%SIZE;
	 for(i=0;i<SIZE;i++)
        {
                index=(hkey+i)%SIZE;
                if(h[index]==ele)
                {
                        printf("VaLUE FOUND AT INDEX %d", index);
                        break;
                }
        }
        if(i==SIZE)
                printf("\nvalue not found\n");
}
void delete()
{
        int ele,index,i,flag=0,hkey;
        printf("\nenter search elmnet\n");
        scanf("%d",&ele);
        hkey=ele%SIZE;
         for(i=0;i<SIZE;i++)
        {
                index=(hkey+i)%SIZE;
                if(h[index]==ele)
                {
           		printf("VaLUE FOUND AT INDEX %d", index);
                         h[index]=NULL;
	   		break;
                } 
        }
        if(i==SIZE)
                printf("\nvalue not found\n");
}
void display()
{
	int i;
	printf("\nelements in the hash Table are\n");
        for(i=0;i<SIZE;i++)
        {
                if(h[i]==NULL)
                
                        printf("\nat index %d\t value=---",i);
		
			else
		        printf("\nat index %d\t value=%d",i,h[i]);
                }
        }
int main()
{
	int ch,i;
	while(1)
	{
		printf("\n 1.Insert\n2.display\n3.Search\n4.remove\n5.Exit\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:insert();
				break;
			case 2:display();
			       break; 
			case 3:search();
			       break;
			case 4:delete();
			       break;
			case 5:exit(0);
		}
	}
	return 0;
}


