#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *a,i,j,n,key;
	printf("enter the size of list:");
	scanf("%d",&n);
	a=(int*)malloc((n+1)*sizeof(int));
	printf("\nEnter %d elements:",n);
 for(i=0;i<n;i++) {
scanf("%d",&a[i]);
}
printf("\nElements before sorting are: \n");
for(i=0;i<n;i++)
printf("%d\t",a[i]);
for(i=1;i<n;i++)
{
key=a[i];
for(j=i-1;j>=0&&a[j]>key;j--)
{
a[j+1]=a[j];
}
a[j+1]=key;
}
printf("\nElements after sorting are: \n");
for(i=0;i<n;i++)
printf("%d\t",a[i]);
return 0;
}
